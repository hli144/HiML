```python
import scipy
import matplotlib
import pandas
import statsmodels
import seaborn
import sklearn
import numpy

print("numpy:", numpy.__version__)
print("scipy:", scipy.__version__)
print("matplotlib:", matplotlib.__version__)
print("statsmodels:", statsmodels.__version__)
print("pandas:", pandas.__version__)
print("seaborn:", seaborn.__version__)
print("sklearn:", sklearn.__version__)
```

    numpy: 1.18.1
    scipy: 1.4.1
    matplotlib: 3.1.3
    statsmodels: 0.11.0
    pandas: 1.0.1
    seaborn: 0.10.0
    sklearn: 0.22.1
    


```python
s=1
w=2
s-w
```




    -1




```python
import matplotlib.pylab as plt
```


```python
plt.bar([1,2,3],[3,2,1])
```




    <BarContainer object of 3 artists>




![png](output_3_1.png)



```python

```
